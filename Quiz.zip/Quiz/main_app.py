from flask import Flask, render_template, request, redirect, session

app = Flask(__name__, template_folder="pages")
app.secret_key = "quizsecret123"

# In-memory users
users = {}

# Quiz questions: 5 questions for 5 topics (example)
quiz_data = {
    "Math": [
        {"question":"5 + 7 = ?", "options":["10","12","13","14"], "answer":"12", "hint":"Think of 5 + 7."},
        {"question":"12 x 2 = ?", "options":["24","22","26","28"], "answer":"24", "hint":"Multiply 12 by 2."},
        {"question":"Square root of 49?", "options":["5","6","7","8"], "answer":"7", "hint":"Which number times itself gives 49?"},
        {"question":"15 - 9 = ?", "options":["5","6","7","8"], "answer":"6", "hint":"Subtract carefully."},
        {"question":"10 ÷ 2 = ?", "options":["2","3","4","5"], "answer":"5", "hint":"Divide 10 by 2."}
    ],
    "Science": [
        {"question":"Water formula?", "options":["H2O","CO2","O2","H2"], "answer":"H2O", "hint":"Common chemical."},
        {"question":"Sun rises in?", "options":["East","West","North","South"], "answer":"East", "hint":"Direction."},
        {"question":"Earth is?", "options":["Flat","Sphere","Cube","Cylinder"], "answer":"Sphere", "hint":"Shape."},
        {"question":"Boiling point of water?", "options":["100°C","90°C","120°C","80°C"], "answer":"100°C", "hint":"Standard."},
        {"question":"Light speed?", "options":["300000 km/s","150000 km/s","100000 km/s","500000 km/s"], "answer":"300000 km/s", "hint":"Fastest."}
    ],
    "History": [
        {"question":"Who discovered America?", "options":["Columbus","Newton","Einstein","Magellan"], "answer":"Columbus", "hint":"1492."},
        {"question":"First President of USA?", "options":["Lincoln","Washington","Adams","Jefferson"], "answer":"Washington", "hint":"George."},
        {"question":"French Revolution year?", "options":["1789","1776","1800","1799"], "answer":"1789", "hint":"18th century."},
        {"question":"Who invented printing press?", "options":["Gutenberg","Tesla","Edison","Bell"], "answer":"Gutenberg", "hint":"15th century."},
        {"question":"Fall of Rome?", "options":["476 AD","500 AD","400 AD","450 AD"], "answer":"476 AD", "hint":"Late Roman Empire."}
    ],
    "Geography": [
        {"question":"Highest mountain?", "options":["Everest","K2","Kangchenjunga","Lhotse"], "answer":"Everest", "hint":"Nepal."},
        {"question":"Longest river?", "options":["Nile","Amazon","Yangtze","Mississippi"], "answer":"Nile", "hint":"Africa."},
        {"question":"Largest ocean?", "options":["Pacific","Atlantic","Indian","Arctic"], "answer":"Pacific", "hint":"Blue."},
        {"question":"Capital of India?", "options":["Delhi","Mumbai","Kolkata","Chennai"], "answer":"Delhi", "hint":"National capital."},
        {"question":"Desert in Africa?", "options":["Sahara","Gobi","Kalahari","Thar"], "answer":"Sahara", "hint":"Hot desert."}
    ],
    "English": [
        {"question":"Synonym of happy?", "options":["Sad","Joyful","Angry","Tired"], "answer":"Joyful", "hint":"Feeling good."},
        {"question":"Antonym of big?", "options":["Small","Huge","Large","Tall"], "answer":"Small", "hint":"Opposite."},
        {"question":"Plural of mouse?", "options":["Mouses","Mice","Meese","Mouse"], "answer":"Mice", "hint":"Irregular."},
        {"question":"Past tense of go?", "options":["Went","Gone","Go","Goes"], "answer":"Went", "hint":"Simple past."},
        {"question":"Article in English?", "options":["A","B","C","D"], "answer":"A", "hint":"Grammar."}
    ]
}

# ---------- Routes ----------

@app.route("/")
def home():
    return render_template("home.html")

@app.route("/register", methods=["GET","POST"])
def register():
    message = ""
    if request.method=="POST":
        username = request.form["username"]
        password = request.form["password"]
        if username in users:
            message = "Username already exists!"
        else:
            users[username] = password
            return redirect("/login")
    return render_template("register.html", message=message)

@app.route("/login", methods=["GET","POST"])
def login():
    message = ""
    if request.method=="POST":
        username = request.form["username"]
        password = request.form["password"]
        if username in users and users[username]==password:
            session["user"] = username
            return redirect("/choose_topic")
        else:
            message = "Invalid username or password!"
    return render_template("login.html", message=message)

@app.route("/choose_topic", methods=["GET","POST"])
def choose_topic():
    if "user" not in session:
        return redirect("/login")
    topics = list(quiz_data.keys())
    if request.method=="POST":
        topic = request.form["topic"]
        session["topic"] = topic
        session["q_index"] = 0
        session["score"] = 0
        return redirect("/quiz")
    return render_template("choose_topic.html", topics=topics)

@app.route("/quiz", methods=["GET","POST"])
def quiz():
    if "user" not in session or "topic" not in session:
        return redirect("/login")
    topic = session["topic"]
    questions = quiz_data[topic]
    q_index = session.get("q_index",0)

    if request.method=="POST":
        selected = request.form.get("option")
        if selected == questions[q_index]["answer"]:
            session["score"] += 1
        session["q_index"] += 1
        q_index = session["q_index"]
        if q_index >= len(questions):
            return redirect("/result")

    question = questions[q_index]
    progress = int((q_index/len(questions))*100)
    return render_template("quiz_board.html", question=question, q_number=q_index+1, total=len(questions), progress=progress)

@app.route("/result")
def result():
    # 1️⃣ Get the score first
    score = session.get("score", 0)
    total = len(quiz_data.get(session.get("topic", "Math"), []))

    # 2️⃣ Generate HTML to display the score
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Quiz Result</title>
        <style>
            body {{ font-family: Arial; display:flex; justify-content:center; align-items:center; height:100vh; background:#f6d365; }}
            .container {{ background:white; padding:40px; border-radius:15px; text-align:center; box-shadow:0 10px 20px rgba(0,0,0,0.2); }}
            h2 {{ margin-bottom:20px; }}
            p {{ font-size:20px; margin-bottom:30px; }}
            .btn {{ padding:12px 25px; font-size:16px; border:none; border-radius:10px; cursor:pointer; margin:5px; background:#4dabf7; color:white; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h2>Quiz Completed!</h2>
            <p>Your Score: {score} / {total}</p>
            <form action="/choose_topic" method="get">
                <button type="submit" class="btn">Play Again</button>
            </form>
            <form action="/logout" method="get">
                <button type="submit" class="btn">Logout</button>
            </form>
        </div>
    </body>
    </html>
    """

    # 3️⃣ Clear session after generating HTML
    session.pop("score", None)
    session.pop("q_index", None)
    session.pop("topic", None)

    return html_content

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

# ---------- Run App ----------
if __name__ == "__main__":
    app.run(debug=True)